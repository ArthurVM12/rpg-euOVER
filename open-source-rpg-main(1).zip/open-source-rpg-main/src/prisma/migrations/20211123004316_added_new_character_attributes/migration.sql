-- AlterTable
ALTER TABLE `character` ADD COLUMN `injured_character_picture_url` VARCHAR(191) NULL,
    ADD COLUMN `standard_character_picture_url` VARCHAR(191) NULL;
